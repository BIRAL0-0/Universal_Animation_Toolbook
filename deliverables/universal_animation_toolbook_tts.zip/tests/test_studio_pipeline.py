#!/usr/bin/env python3
"""End-to-end Python, Voice Sync, Board/Camera Timing & BGM pipeline tests for Universal Animation Toolbook."""

from __future__ import annotations

import json
import struct
import sys
import tempfile
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "universal_toolbook"
sys.path.insert(0, str(ROOT))

from engine.bgm_library import load_bgm_catalog, render_bgm_bed, score_script_for_bgm
from engine.voice_engine import (
    align_scene_board_to_speech,
    align_scene_cameras_to_speech,
    compact_internal_silences_with_words,
    _attach_source_text,
    _compact_piper_line,
)
from tools.fetch_piper_voices import hf_relpath
from tools.script_helper import segment_user_script, verify_script_fidelity

sys.path.insert(0, str(ROOT.parent))
from universal_toolbook.run_studio import (  # noqa: E402
    _is_shorts_duration,
    _is_short_form_duration,
    _render_dimensions,
    _resolve_aspect_ratio,
    _voice_diagnosis,
    build_parser,
)


def main() -> int:
    # 0. Aspect-ratio profiles preserve 16:9 / 9:16 dimensions at draft and master sizes.
    assert _render_dimensions("16:9") == (1920, 1080)
    assert _render_dimensions("9:16") == (1080, 1920)
    assert _render_dimensions("16:9", draft=True) == (960, 540)
    assert _render_dimensions("9:16", draft=True) == (540, 960)
    parser = build_parser()
    portrait_args = parser.parse_args(["render", "episode.json", "--aspect", "9:16"])
    short_default_args = parser.parse_args(["render", "episode.json", "--short-form"])
    # Keep the generic duration gate aspect-independent; this is not the reference delivery pair.
    generic_landscape_args = parser.parse_args(
        ["render", "episode.json", "--aspect-ratio", "16:9", "--short-form"]
    )
    short_portrait_args = parser.parse_args(
        ["render", "episode.json", "--aspect-ratio", "9:16", "--short-form"]
    )
    shorts_args = parser.parse_args(["render", "episode.json", "--shorts"])
    assert portrait_args.aspect_ratio == "9:16" and portrait_args.shorts is False
    assert short_default_args.short_form and not short_default_args.shorts
    assert _resolve_aspect_ratio(
        short_default_args.aspect_ratio, short_default_args.shorts
    ) == "16:9"
    assert _resolve_aspect_ratio(
        generic_landscape_args.aspect_ratio, generic_landscape_args.shorts
    ) == "16:9"
    assert _resolve_aspect_ratio(
        short_portrait_args.aspect_ratio, short_portrait_args.shorts
    ) == "9:16"
    assert shorts_args.shorts is True and shorts_args.aspect_ratio is None
    assert _resolve_aspect_ratio(shorts_args.aspect_ratio, shorts_args.shorts) == "9:16"
    try:
        _resolve_aspect_ratio("16:9", shorts=True)
        raise AssertionError("--shorts must reject an explicit landscape aspect")
    except ValueError:
        pass
    assert _is_short_form_duration(40) and _is_short_form_duration(90)
    assert not _is_short_form_duration(39.99) and not _is_short_form_duration(90.01)
    assert not _is_short_form_duration(float("nan"))
    assert _is_shorts_duration(0.01) and _is_shorts_duration(40)
    assert _is_shorts_duration(90) and _is_shorts_duration(180)
    assert not _is_shorts_duration(0) and not _is_shorts_duration(-1)
    assert not _is_shorts_duration(180.01) and not _is_shorts_duration(float("nan"))

    # 1. Verify all 7 bundled Creative Commons / NCS-style BGM tracks exist & load
    catalog = load_bgm_catalog()
    assert len(catalog) == 7, f"Expected 7 bundled CC/NCS BGM tracks, got {len(catalog)}"
    for item in catalog:
        fpath = ROOT / "assets" / "bgm" / item["file"]
        assert fpath.exists() and fpath.stat().st_size > 500_000, f"Missing BGM {fpath}"

    # 2. Verify script-mood BGM matcher responds accurately to script vocabulary
    tech_pick = score_script_for_bgm("algorithm data system code engineer strategy", [], catalog)
    assert tech_pick["id"] == "electronic_drive"

    suspense_pick = score_script_for_bgm("mystery crime danger crisis collapse secret risk", [], catalog)
    assert suspense_pick["id"] == "suspense_tension"

    ncs_pick = score_script_for_bgm("fast energy challenge launch momentum sport action win", [], catalog)
    assert ncs_pick["id"] == "upbeat_ncs_synth"

    # 3. Verify seamless loop crossfade rendering for >3.5 minute duration
    fake_ep = {"title": "Test", "thesis": "Data", "scenes": [{"mood": "focus", "narration": "system code"}]}
    bed, meta = render_bgm_bed(44100 * 210, fake_ep, bgm_choice="auto")
    assert bed.shape == (44100 * 210, 2)
    assert meta["selected_id"] == "electronic_drive"

    # 4. Verify script_helper preserves 100% of exact user script wording with neutral roles
    custom_script = (
        "[Chapter: Opening Premise]\n"
        "Every complex system begins with a simple rule. When builders test ideas in the real world, "
        "data reveals what assumptions hide.\n\n"
        "Consistency compounds quietly until the outcome becomes undeniable."
    )
    parsed = segment_user_script(custom_script, title="Universal Test", target_words_per_scene=22)
    fidelity = verify_script_fidelity(custom_script, parsed)
    assert fidelity["exact_word_match"] is True, f"Script mismatch: {fidelity}"

    # 5. Silence cleanup trims TTS dead air, keeps punctuation pauses, and shifts word sync.
    sr = 44100
    with tempfile.TemporaryDirectory() as td:
        tone = [4000 if (i % 40) < 20 else -4000 for i in range(int(0.40 * sr))]
        sil = [0] * int(0.85 * sr)
        words_in = [
            {"word": "First", "start": 0.05, "end": 0.38},
            {"word": "Second", "start": 1.25, "end": 1.60},
        ]

        def write_gap_wav(path: Path) -> None:
            pcm = tone + sil + tone  # 0.40s tone + 0.85s gap + 0.40s tone = 1.65s
            with wave.open(str(path), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(struct.pack(f"<{len(pcm)}h", *pcm))

        wav_path = Path(td) / "test_pause.wav"
        write_gap_wav(wav_path)
        new_dur, words_out = compact_internal_silences_with_words(wav_path, words_in)
        assert new_dur < 1.00, f"Expected unpunctuated 0.85s TTS dead air to compact, got {new_dur}"
        assert abs(words_out[0]["start"] - 0.05) < 0.01
        assert words_out[1]["start"] < 0.60, f"Expected the second word timestamp to shift with audio, got {words_out[1]}"

        for index, (punctuated, lower, upper) in enumerate([
            ("First,", 1.00, 1.10),   # keep a short clause pause
            ("First.", 1.18, 1.28),  # retain a clearer sentence boundary
            ("First...", 1.62, 1.68),  # ellipsis is explicitly intentional; leave it intact
        ]):
            punct_path = Path(td) / f"pause_{index}.wav"
            write_gap_wav(punct_path)
            punct_words = _attach_source_text(
                [
                    {"word": "First", "start": 0.05, "end": 0.38},
                    {"word": "Second", "start": 1.25, "end": 1.60},
                ],
                f"{punctuated} Second",
            )
            punct_dur, _ = compact_internal_silences_with_words(punct_path, punct_words)
            assert lower <= punct_dur <= upper, f"Unexpected pause handling after {punctuated!r}: {punct_dur}"

        piper_path = Path(td) / "piper_uncompacted.wav"
        write_gap_wav(piper_path)
        piper_dur, piper_words = _compact_piper_line(piper_path, "First word", 1.65)
        assert piper_dur < 1.00, f"Piper post-processing should compact TTS dead air, got {piper_dur}"
        assert len(piper_words) == 2 and abs(piper_words[1]["start"] - 0.52) < 0.10, piper_words

    # 6. Verify V3 speech-locked board & camera `cue_on` / `hide_on` (never misfires on earlier stopwords!)
    mock_words = [
        {"word": "No", "start": 0.40, "end": 0.65},
        {"word": "one", "start": 0.68, "end": 0.90},
        {"word": "saw", "start": 0.95, "end": 1.20},
        {"word": "the", "start": 1.25, "end": 1.40},
        {"word": "cost", "start": 1.45, "end": 1.85},
        {"word": "until", "start": 4.20, "end": 4.50},
        {"word": "no", "start": 4.55, "end": 4.75},
        {"word": "excuses", "start": 4.80, "end": 5.35},
        {"word": "turned", "start": 7.80, "end": 8.15},
        {"word": "into", "start": 8.20, "end": 8.45},
        {"word": "burnout", "start": 8.50, "end": 9.10},
    ]
    mock_scene = {
        "board": {
            "type": "stat_cards",
            "cue_on": "no excuses",
            "hide_on": "burnout",
        },
        "camera_shots": [
            {"start": 0.0, "end": 3.0, "zoom_from": 1.0, "zoom_to": 1.05},
            {"cue_on": "no excuses", "zoom_from": 1.18, "zoom_to": 1.24},
            {"cue_on": "turned into burnout", "zoom_from": 1.08, "zoom_to": 1.02},
        ],
    }
    align_scene_board_to_speech(mock_scene, mock_words, 16.0)
    align_scene_cameras_to_speech(mock_scene, mock_words, 16.0)

    rev_at = mock_scene["board"]["reveal_at"]
    hide_at = mock_scene["board"]["hide_at"]
    assert 4.45 <= rev_at <= 4.60, f"Board must NOT trigger prematurely on 'No' at 0.40s; got {rev_at}"
    assert 9.50 <= hide_at <= 9.80, f"Board must hide cleanly right after 'burnout' at 9.10s; got {hide_at}"
    assert abs(mock_scene["camera_shots"][1]["start"] - 4.49) < 0.10
    assert abs(mock_scene["camera_shots"][2]["start"] - 7.74) < 0.10

    # 3. A voice run that synthesizes nothing must explain itself instead of failing silently:
    #    the renderer turns this diagnosis into `status: COMPLETE_SILENT` + exit code 3.
    missing_edge = _voice_diagnosis({"edge_tts": False})
    assert missing_edge, "voice diagnosis must never be empty when no backend produced speech"
    assert any("pip install" in line for line in missing_edge), missing_edge
    assert any("edge-tts is not installed" in line for line in missing_edge), missing_edge
    # 3b. The documented voice install command must resolve real canonical URLs, not a guess:
    #     huggingface.co/rhasspy/piper-voices nests voices as <lang>/<lang_REGION>/<name>/<quality>.
    assert hf_relpath("en_US-ryan-medium") == "en/en_US/ryan/medium", hf_relpath("en_US-ryan-medium")
    assert hf_relpath("en_GB-alan-medium") == "en/en_GB/alan/medium", hf_relpath("en_GB-alan-medium")
    assert hf_relpath("en_US-amy-low") == "en/en_US/amy/low", hf_relpath("en_US-amy-low")

    with_edge = _voice_diagnosis({"edge_tts": True})
    assert any("no internet" in line for line in with_edge), with_edge
    assert any("piper-tts" in line for line in with_edge), with_edge

    print(
        json.dumps(
            {
                "py_tests": "PASSED",
                "voice_failure_diagnosis": "PASSED",
                "canonical_voice_url_layout": "PASSED",
                "bgm_tracks_verified": len(catalog),
                "script_mood_matching": "PASSED",
                "silence_compactor_verified": True,
                "speech_locked_board_and_camera_verified": True,
                "exact_word_match": True,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
